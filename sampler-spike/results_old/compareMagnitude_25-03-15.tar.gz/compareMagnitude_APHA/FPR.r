setwd("/home/per024/ENVIRONMENT/workspaces/Sampler/sampler-spike/results/compareMagnitude")

        
      data = read.csv("FPR.csv")
      y1 = data[[1]]
      y2 = data[[2]]
      x = 1:length(y1)
            
      cmin = min(y1, y2)
      cmax = max(y1, y2)
      
      pdf("FPR.pdf", width=4.13, height=2.91) #A7 landscape paper
      
      plot(x, y1, type="l", col=2, lwd=5, ylim = c(cmin, cmax), xlab="Magnitude of outbreak", ylab="False positive rate", )
      lines(x, y2, col=3, lwd=5)
      legend("topright", xpd=TRUE, inset=c(0.2,-0.65), legend=c("any alert", "consecutive alerts"), fill=2:3)
      
      dev.off()
      
